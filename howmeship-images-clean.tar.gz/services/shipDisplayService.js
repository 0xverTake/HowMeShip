const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

class ShipDisplayService {
    constructor() {
        this.shipImages = this.loadShipImages();
    }

    /**
     * Charge les URLs d'images des vaisseaux depuis le fichier local
     */
    loadShipImages() {
        try {
            const imagePath = path.join(__dirname, '..', 'data', 'ship_images_urls_complete.json');
            if (fs.existsSync(imagePath)) {
                const data = JSON.parse(fs.readFileSync(imagePath, 'utf8'));
                console.log(`📸 ${data.metadata.totalShips} URLs d'images chargées depuis le fichier local`);
                return data.ships;
            }
        } catch (error) {
            console.error('❌ Erreur lors du chargement des images:', error.message);
        }
        return {};
    }

    /**
     * Trouve l'URL d'image pour un vaisseau donné
     */
    getShipImageUrl(shipName) {
        if (!this.shipImages || Object.keys(this.shipImages).length === 0) {
            return null;
        }

        // Recherche directe par nom exact
        for (const [key, shipData] of Object.entries(this.shipImages)) {
            if (shipData.name && shipData.name.toLowerCase() === shipName.toLowerCase()) {
                return shipData.imageUrl || shipData.thumbnailUrl;
            }
        }

        // Recherche par clé (format: MANUFACTURER_SHIP_VARIANT)
        const normalizedName = shipName.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase();
        for (const [key, shipData] of Object.entries(this.shipImages)) {
            if (key.includes(normalizedName) || normalizedName.includes(key.replace('_', ' '))) {
                return shipData.imageUrl || shipData.thumbnailUrl;
            }
        }

        // Recherche partielle
        const searchTerms = shipName.toLowerCase().split(' ');
        for (const [key, shipData] of Object.entries(this.shipImages)) {
            const nameWords = (shipData.name || '').toLowerCase().split(' ');
            if (searchTerms.some(term => nameWords.some(word => word.includes(term)))) {
                return shipData.imageUrl || shipData.thumbnailUrl;
            }
        }

        return null;
    }

    /**
     * Crée un embed enrichi pour un vaisseau avec image et caractéristiques
     * @param {Object} ship - Données de base du vaisseau
     * @param {Object} options - Options d'affichage
     * @returns {Object} Embed et attachments pour Discord
     */
    async createShipEmbed(ship, options = {}) {
        const {
            color = '#0099ff',
            showSpecs = true,
            showImage = true,
            showPrice = true,
            compact = false
        } = options;

        try {
            const embed = new EmbedBuilder()
                .setColor(color)
                .setTitle(`🚀 ${ship.name}`)
                .setTimestamp();

            let attachments = [];

            // Ajouter l'image si disponible et demandée
            if (showImage) {
                const imageUrl = this.getShipImageUrl(ship.name);
                if (imageUrl) {
                    embed.setImage(imageUrl);
                }
            }

            // Ajouter la description si disponible
            if (ship.description && !compact) {
                const description = ship.description.length > 300 
                    ? ship.description.substring(0, 297) + '...'
                    : ship.description;
                embed.setDescription(description);
            }

            // Informations de base
            const basicInfo = [];
            
            if (ship.manufacturer) {
                basicInfo.push(`**Fabricant:** ${ship.manufacturer}`);
            }
            
            if (ship.category) {
                basicInfo.push(`**Catégorie:** ${ship.category}`);
            }

            if (showPrice && ship.price) {
                basicInfo.push(`**Prix:** $${ship.price.toLocaleString()}`);
            }

            if (ship.focus) {
                basicInfo.push(`**Rôle:** ${ship.focus}`);
            }

            if (ship.size) {
                basicInfo.push(`**Taille:** ${ship.size}`);
            }

            if (basicInfo.length > 0) {
                embed.addFields({
                    name: '📋 Informations générales',
                    value: basicInfo.join('\n'),
                    inline: false
                });
            }

            // Ajouter les spécifications techniques si disponibles et demandées
            if (showSpecs && ship.specifications) {
                try {
                    const specs = typeof ship.specifications === 'string' 
                        ? JSON.parse(ship.specifications) 
                        : ship.specifications;
                    this.addSpecificationsToEmbed(embed, specs, compact);
                } catch (e) {
                    // Ignore les erreurs de parsing JSON
                }
            }

            // Footer avec source des données
            const footerText = 'Données locales • Images Star Citizen Wiki';
            embed.setFooter({ text: footerText });

            return {
                embeds: [embed],
                files: attachments
            };

        } catch (error) {
            console.error('❌ Erreur lors de la création de l\'embed:', error);
            
            // Embed de fallback en cas d'erreur
            const fallbackEmbed = new EmbedBuilder()
                .setColor('#ff6b6b')
                .setTitle(`🚀 ${ship.name}`)
                .setDescription('Informations de base disponibles')
                .addFields({
                    name: '📋 Informations',
                    value: [
                        ship.manufacturer ? `**Fabricant:** ${ship.manufacturer}` : null,
                        ship.category ? `**Catégorie:** ${ship.category}` : null,
                        ship.price ? `**Prix:** $${ship.price.toLocaleString()}` : null
                    ].filter(Boolean).join('\n') || 'Aucune information disponible'
                })
                .setTimestamp();

            return {
                embeds: [fallbackEmbed],
                files: []
            };
        }
    }

    /**
     * Ajoute les spécifications techniques à l'embed
     * @param {EmbedBuilder} embed - Embed à modifier
     * @param {Object} specifications - Spécifications du vaisseau
     * @param {boolean} compact - Mode compact
     */
    addSpecificationsToEmbed(embed, specifications, compact = false) {
        // Organiser les spécifications
        const organizedSpecs = {
            dimensions: [],
            performance: [],
            combat: [],
            other: []
        };

        for (const [key, value] of Object.entries(specifications)) {
            const lowerKey = key.toLowerCase();
            
            if (lowerKey.includes('length') || lowerKey.includes('beam') || lowerKey.includes('height') || lowerKey.includes('mass')) {
                organizedSpecs.dimensions.push(`**${key}:** ${value}`);
            } else if (lowerKey.includes('speed') || lowerKey.includes('cargo') || lowerKey.includes('crew') || lowerKey.includes('fuel')) {
                organizedSpecs.performance.push(`**${key}:** ${value}`);
            } else if (lowerKey.includes('shield') || lowerKey.includes('armor') || lowerKey.includes('weapon') || lowerKey.includes('missile')) {
                organizedSpecs.combat.push(`**${key}:** ${value}`);
            } else {
                organizedSpecs.other.push(`**${key}:** ${value}`);
            }
        }

        // Ajouter les champs selon le mode
        if (compact) {
            // Mode compact : tout dans un seul champ
            const allSpecs = [
                ...organizedSpecs.dimensions,
                ...organizedSpecs.performance,
                ...organizedSpecs.combat,
                ...organizedSpecs.other
            ].slice(0, 10); // Limiter à 10 spécifications

            if (allSpecs.length > 0) {
                embed.addFields({
                    name: '⚙️ Spécifications',
                    value: allSpecs.join('\n'),
                    inline: true
                });
            }
        } else {
            // Mode détaillé : champs séparés
            if (organizedSpecs.dimensions.length > 0) {
                embed.addFields({
                    name: '📏 Dimensions',
                    value: organizedSpecs.dimensions.join('\n'),
                    inline: true
                });
            }

            if (organizedSpecs.performance.length > 0) {
                embed.addFields({
                    name: '⚡ Performance',
                    value: organizedSpecs.performance.join('\n'),
                    inline: true
                });
            }

            if (organizedSpecs.combat.length > 0) {
                embed.addFields({
                    name: '⚔️ Combat',
                    value: organizedSpecs.combat.join('\n'),
                    inline: true
                });
            }

            if (organizedSpecs.other.length > 0 && organizedSpecs.other.length <= 5) {
                embed.addFields({
                    name: '🔧 Autres',
                    value: organizedSpecs.other.join('\n'),
                    inline: true
                });
            }
        }
    }

    /**
     * Crée un embed de comparaison entre deux vaisseaux
     * @param {Object} ship1 - Premier vaisseau
     * @param {Object} ship2 - Deuxième vaisseau
     * @returns {Object} Embed de comparaison
     */
    async createComparisonEmbed(ship1, ship2) {
        try {
            const embed = new EmbedBuilder()
                .setColor('#ff9900')
                .setTitle(`⚖️ Comparaison: ${ship1.name} vs ${ship2.name}`)
                .setTimestamp();

            // Comparaison des prix
            if (ship1.price && ship2.price) {
                const difference = Math.abs(ship1.price - ship2.price);
                const cheaper = ship1.price < ship2.price ? ship1.name : ship2.name;

                embed.addFields({
                    name: '💰 Prix',
                    value: `**${ship1.name}:** $${ship1.price.toLocaleString()}\n**${ship2.name}:** $${ship2.price.toLocaleString()}\n\n🏆 **${cheaper}** est moins cher de $${difference.toLocaleString()}`,
                    inline: false
                });
            }

            // Comparaison des caractéristiques de base
            const comparison = [];
            
            if (ship1.manufacturer && ship2.manufacturer) {
                comparison.push(`**Fabricant:**\n• ${ship1.name}: ${ship1.manufacturer}\n• ${ship2.name}: ${ship2.manufacturer}`);
            }
            
            if (ship1.category && ship2.category) {
                comparison.push(`**Catégorie:**\n• ${ship1.name}: ${ship1.category}\n• ${ship2.name}: ${ship2.category}`);
            }

            if (ship1.size && ship2.size) {
                comparison.push(`**Taille:**\n• ${ship1.name}: ${ship1.size}\n• ${ship2.name}: ${ship2.size}`);
            }

            if (comparison.length > 0) {
                embed.addFields({
                    name: '⚙️ Caractéristiques',
                    value: comparison.join('\n\n'),
                    inline: false
                });
            }

            embed.setFooter({ text: 'Comparaison basée sur les données locales' });

            return {
                embeds: [embed],
                files: []
            };

        } catch (error) {
            console.error('Erreur lors de la création de la comparaison:', error);
            
            const errorEmbed = new EmbedBuilder()
                .setColor('#ff6b6b')
                .setTitle('❌ Erreur de comparaison')
                .setDescription('Impossible de comparer ces vaisseaux pour le moment.')
                .setTimestamp();

            return {
                embeds: [errorEmbed],
                files: []
            };
        }
    }

    /**
     * Met à jour les détails d'un vaisseau en arrière-plan (placeholder)
     * @param {string} shipName - Nom du vaisseau
     */
    async updateShipDetails(shipName) {
        // Placeholder - pas de mise à jour nécessaire avec les données locales
        console.log(`🔄 Mise à jour de ${shipName} (données locales)`);
    }

    /**
     * Obtient les statistiques du service d'images
     * @returns {Object} Statistiques
     */
    getStats() {
        return {
            totalImages: Object.keys(this.shipImages).length,
            loadedFromLocal: true,
            lastUpdate: new Date().toISOString()
        };
    }

    /**
     * Nettoie le cache des images (placeholder)
     * @param {number} maxAge - Âge maximum en jours
     */
    cleanup(maxAge = 30) {
        console.log('🧹 Nettoyage du cache (données locales - pas de nettoyage nécessaire)');
    }
}

module.exports = new ShipDisplayService();
